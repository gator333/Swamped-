const CONFIG = {
  enableKrakenFetcher: true,
  enableScannerCore: true,
  enableLiveWebSocketWatch: true,
  enableUIEnhancements: true
};